<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width , initial-scale =1.0" >
    <title> ELEZAPY PHARMACY </title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('css/normalize.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/all.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/util.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/A.style.css.pagespeed.cf.mMBCBFkmOw.css')); ?>">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">
    <link rel="stylesheet" href="<?php echo e(asset('css/pogo-slider.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">    
    <link rel="stylesheet" href="<?php echo e(asset('css/responsive.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
</head>

<body>
    
                    <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p> <?php echo e($error); ?> </p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?> 
                     <form class="w-50 m-auto pt-5" action='<?php echo e(url("/clients/$client->id")); ?>' method="post" enctype="multipart/form-data ">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("PUT"); ?>
                  

                        <div class="modal-header">						
                            <h4 class="modal-title">EDIT CLIENT</h4>
                        </div>
                        <div class="modal-body">					
                            <div class="form-group">
                                <label> Product Name</label>
                                <input type="text" name="name" value="<?php echo e($client->name); ?>" class="form-control" required>
                            </div>
                        
                            <div class="form-group">
                                <label>National Id</label>
                                <input type="text" class="form-control" value="<?php echo e($client->nationalid); ?>" name="nationalid" required >
                            </div>		
                            <div class="form-group">
                                <label>Address</label>
                                <input type="text" class="form-control" value="<?php echo e($client->address); ?>" name="address" required >
                            </div>	
                            <div class="form-group">
                                <label>Phone</label>
                                <input type="text" class="form-control" value="<?php echo e($client->phone); ?>" name="phone" required >
                            </div>					
                        </div>
                        <div class="modal-footer">
                            <input type="submit" class="btn btn-success" value="EDIT" name="add">
                        </div>
                    </form>
                

     <script src="stylesheet" href="<?php echo e(asset('js/index.js')); ?>"></script>
    <script src="stylesheet" href="<?php echo e(asset('js/jquery.nicescroll.min.js')); ?>"></script>
    <script src="stylesheet" href="<?php echo e(asset('js/jquery-3.5.1.min.js')); ?>"></script>
  
</body>
</html>
 <?php /**PATH G:\ALL OLD DATA\WEB PROJECTS\laravel\graduationproject\example-app\resources\views/clients/edit.blade.php ENDPATH**/ ?>